package com.tsunglin.tsunglin00.kafka_consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaConsumer.class);

    @KafkaListener(topics = KafkaConfig1.TEST_TOPIC, groupId = KafkaConfig1.GROUP_1)

    /*
    public void consume(String message) {
        LOGGER.info("Consumed message: {} ", message);
    }
    */
    /*
    何時觸發 Retry 與 Retry 期間訊息的狀態
    當 Consumer 在處理訊息中拋出例外錯誤就會觸發 Retry 機制，在 Retry 期間 Consumer 的 thread 會暫停接收訊息直到 Retry 結束。
    為了方便測試，這裡設定如果文字訊息中含有「retry」這個字就拋出例外錯誤。
    */
    public void consume(String message) {
        LOGGER.info("Consumed message: {} ", message);
        LOGGER.info("Call other API...... ");
        if (message.contains("retry")) {
            LOGGER.info("Incompatible message {} ", message);
            throw new RuntimeException("Incompatible message " + message);
        }
        LOGGER.info("Consumed done. ");
    }

    @KafkaListener(topics = KafkaConfig1.JSON_TOPIC, groupId = KafkaConfig1.GROUP_2,
            containerFactory = "userKafkaListenerFactory")
    public void consumeJson(UserVo1 user) throws InterruptedException {
        LOGGER.info("Consumed JSON Message: {} ", user);
    }
}