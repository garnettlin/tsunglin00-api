package com.tsunglin.tsunglin00.kafka_consumer;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.tsunglin.tsunglin00.kafka_consumer.UserVo1;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.LoggingErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

@EnableKafka
@Configuration
public class KafkaConfig1 {

    public static final String TEST_TOPIC = "test";
    public static final String JSON_TOPIC = "json";
    public static final String DEFAULT_SERVER = "127.0.0.1:9092";
    public static final String GROUP_1 = "group_1";
    public static final String GROUP_2 = "group_2";
    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaConfig1.class);


    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> config = new HashMap<>();

        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, DEFAULT_SERVER);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_1);
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);

        return new DefaultKafkaConsumerFactory<>(config);
    }

    /*
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }
    */
    /*
    Retry 機制
    假設 Consumer 訂閱訊息後需要呼叫其他下游系統，當下游系統正在忙碌中沒有回應，你又想要多重試個幾次呢？
    Spring-Kafka 提供 AbstractKafkaListenerContainerFactory 來配置  spring-retry template，在 retry template 中可以設定要重試幾次以及每次重試間隔的時間多久。
    這裡 retry template 配置了重試 3 次、每次間隔 5 秒。如果下游系統在 retry 的期間恢復運作，那訊息就可以繼續傳遞。
    另外還有設置了 RecoveryCallback，當 retry 都結束了就會觸發，以便做後續處理。
    */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.setRetryTemplate(kafkaRetry());
        factory.setRecoveryCallback(retryContext -> {
            ConsumerRecord<String, String> consumerRecord =
                    (ConsumerRecord) retryContext.getAttribute("record");
            LOGGER.info("Recovery is called for message: {} ", consumerRecord.value());
            return Optional.empty();
        });
        return factory;
    }

    @Bean
    public RetryTemplate kafkaRetry() {
        RetryTemplate retryTemplate = new RetryTemplate();

        FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
        fixedBackOffPolicy.setBackOffPeriod(5 * 1000l);
        retryTemplate.setBackOffPolicy(fixedBackOffPolicy);

        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        retryPolicy.setMaxAttempts(3);
        retryTemplate.setRetryPolicy(retryPolicy);
        return retryTemplate;
    }

    /*
    @Bean
    public ConsumerFactory<String, UserVo1> userConsumerFactory() {
        Map<String, Object> config = new HashMap<>();

        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, DEFAULT_SERVER);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_2);
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        return new DefaultKafkaConsumerFactory<>(config);
    }
    */

    /*
    在實作的過程中，可以發現 Configuration 指定了 KEY 和 VALUE 的型態 ─ 發佈訊息時序列化以及訂閱訊息時反序列化。
    Producer 發佈訊息時 Java Object 轉換成 byte 陣列傳輸到 Kafka Server，Kafka Server 只負責儲存以及分送訊息到指定的主題分區，
    Consumer 訂閱時將 byte 陣列反序列化回 Java Object 。
    當 Producer 序列化型態與 Consumer 在反序列化型態無法匹配時，毒藥訊息的情境就產生了。例如 Producer 將文字訊息傳送給訂閱 JSON 訊息的 Consumer 時， 會發生：
    Consumer 反序列化異常拋出錯誤。
    由於 Consumer offset 沒有往前，訊息被阻塞。
    Consumer 會持續的嘗試反序列化毒藥訊息然後失敗，程式就像進入了一個無窮迴圈，不但無法繼續訂閱訊息且LOG 記錄被大量的、重複的錯誤訊息淹沒，最終導致儲存空間用盡。

    使用 ErrorHandlingDeserializer
    當在 Consumer 配置了 ErrorHandlingDeserializer，收到毒藥訊息時會回傳 null 並增加 DeserializationException 在 ConsumerRecord 的 header，
    ConsumerRecord 會呼叫 container 的 ErrorHandler 來處理，這筆毒藥訊息就不會過到 @KafkaListener 的方法，遏止死循環的產生。
    以下改寫 ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG ，原本直接使用的 JsonDeserializer，現在再多包一層 ErrorHandlingDeserializer 當作 VALUE_DESERIALIZER。
    */
    @Bean
    public ConsumerFactory<String, UserVo1> userConsumerFactory() {
        Map<String, Object> config = new HashMap<>();

        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, DEFAULT_SERVER);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_2);

        // use ErrorHandlingDeserializer
        ErrorHandlingDeserializer<UserVo1> errorHandlingDeserializer =
                new ErrorHandlingDeserializer<>(new JsonDeserializer<>(UserVo1.class));
        return new DefaultKafkaConsumerFactory<>(config, new StringDeserializer(),
                errorHandlingDeserializer);
    }

    /*
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, UserVo1> userKafkaListenerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, UserVo1> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(userConsumerFactory());
        return factory;
    }
    */

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, UserVo1> userKafkaListenerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, UserVo1> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(userConsumerFactory());
        // add ErrorHandler
        factory.setErrorHandler(errorHandler());
        return factory;
    }
    /*
    配置 org.springframework.kafka.listener.LoggingErrorHandler 取代 container 預設的 SeekToCurrentErrorHandler 用來印錯誤訊息。
    */

    @Bean
    public LoggingErrorHandler errorHandler() {
        return new LoggingErrorHandler();
    }
}
