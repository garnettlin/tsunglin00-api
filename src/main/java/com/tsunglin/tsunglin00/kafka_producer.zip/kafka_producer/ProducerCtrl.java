package com.tsunglin.tsunglin00.kafka_producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaSendCallback;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("kafka")
public class ProducerCtrl {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProducerCtrl.class);

    @Autowired
    private KafkaTemplate<String, UserVo> kafkaTemplate;

    @GetMapping("/publish/{dpt}/{id}")
    public String post(@PathVariable("dpt") final String dpt, @PathVariable("id") final String id) {

        UserVo userVo = new UserVo(id, dpt);

        //kafkaTemplate.send(KafkaConfig.JSON_TOPIC, userVo);
        ListenableFuture<SendResult<String, UserVo>> future =
                kafkaTemplate.send(KafkaConfig.JSON_TOPIC, userVo);

        future.addCallback(new KafkaSendCallback<String, UserVo>() {

            @Override
            public void onSuccess(SendResult<String, UserVo> result) {
                LOGGER.info("success send message:{} with offset:{} ", userVo,
                        result.getRecordMetadata().offset());
            }

            @Override
            public void onFailure(KafkaProducerException ex) {
                LOGGER.error("fail send message! Do somthing....");
            }
        });

        return "Published done";
    }
}